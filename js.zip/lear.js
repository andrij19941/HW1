const
  MILK=15.678
  FISH=123.965
  MEAT=90.2345
console.log(Math.max(MILK, FISH, MEAT ));
console.log(Math.min(MILK, FISH, MEAT));

let
  BASKET = MILK+FISH+MEAT;
console.log(BASKET)

console.log(Math.floor(MILK));
console.log(Math.floor(FISH));
console.log(Math.floor(MEAT));
let  
  neoMILK=15
  neoFISH=123
  neoMEAT=90
  neoBASKET=neoMILK+neoFISH+neoMEAT
console.log(neoBASKET);
//console.log(Math.ceil(228))
//alert(Math.round((228)*10)/10);

 


let cash=500
let 
  change = cash - BASKET
console.log(change)

let SALE = BASKET/3
console.log(SALE)

let value=SALE; 
  console.log(Math.round(value*100)/100);

let randomSALE
  console.log(Math.random(randomSALE)*100);
  

let sumaSALE
  sumaSALE = BASKET*0.02
  console.log(sumaSALE)
  console.log(Math.round(0.01769202983540299*100)/100);


let 
  
  TOTAL=BASKET/2-4.07
  console.log(TOTAL)
const isParne = 228%2 ? false : true
  console.log(isParne)
  
  console.log(Math.round(4.066999588487851*100)/100);



